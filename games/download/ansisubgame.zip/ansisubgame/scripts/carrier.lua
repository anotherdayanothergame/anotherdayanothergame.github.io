function runonce()

end

function initialized()
	imagecreate("carrierimg", "root:img/Carrier8.bam")
	initimage("carrierimg")
	setentitysize(this, 10, 5)
	setentitysolid(this, false)
	hull = 500
	movetimer = 60
end

function main()
	cc = dataread("cc")
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	--draw()
	drawimg()
	--drawimage("carrierimg", x - cx, y - cy)
	movecheck()
	hitcheck()
	hullcheck()
	losecheck()
	depthcheck()
	--print("carrier: " .. x .. "," .. y)
end

function always()

end

function movecheck()
	if movetimer <= 0 then
		move(-1, 0)
		movetimer = 60
	else
		movetimer = movetimer - 1
	end
end

function hitcheck()
	local x = getentityx(this)
	local xmax = x + 10
	local y = getentityy(this)
	local ymax = y + 5
	local cx = getcamerax()
	local cy = getcameray()
	local layer = getentitylayer(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "PlayerTorpedo" then
			local ex, ey = getentityxy(ptr)
			local elayer = getentitylayer(ptr)
			-- local fg = getimagefg("carrierimg", ex, ey)
			local fg = getdrawntilefg(ex - cx, ey - cy)
			if ex >= x and ex <= xmax and ey >= y and ey <= ymax and (elayer == 0 or elayer == 1) and fg ~= 255 then
				local dmg = 20 + random(-5, 5)
				hull = hull - dmg
				datasave(tostring(cc), "TARGET HIT")
				datasave(tostring(cc) .. "sym", 15)
				cc = cc + 1
				datasave("cc", cc)
				entitydestroy(ptr)
				print(hull)
			end
		end
	end
end

function hullcheck()
	if hull <= 0 then
		freeimage("carrierimg")
		entitydestroy(this)
		--print("destroyed")
	end
end

function depthcheck()
	local player = getentitylayer(player)
	
	if player == 0 then
		setentitysolid(this, true)
		-- print("solid = " .. tostring(getentitysolid(this)))
	else
		setentitysolid(this, false)
		-- print("solid = " .. tostring(getentitysolid(this)))
	end
end

function losecheck()
	local x = getentityx(this)
	if x <= 1 then
		cc = dataread("cc")
		datasave(tostring(cc), "TARGET LOST")
		datasave(tostring(cc) .. "sym", 247)
		cc = cc + 1
		datasave("cc", cc)
		setentityglobal(player, "lost", "true")
		entityhide(this)
		entityhide(player)
	end
end

function draw()
	local x = getentityx(this)
	local y = getentityy(this)
	drawset(178, 1, 142)
	drawline(x, y + 2, x + 5, y + 2)
	drawline(x + 8, y + 2, x + 9, y + 2)
	drawline(x, y + 3, x + 9, y + 3)
	drawset(219, 1, 142)
	drawline(x + 1, y + 4, x + 8, y + 4)
	drawset(254, 142, 1)
	drawline(x + 6, y, x + 6, y + 2)
	drawline(x + 7, y + 1, x + 7, y + 2)
end

--[[function drawimg()
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	local realx = x - cx
	local realy = y - cy
	local realendx = realx + 15
	local realendy = realy + 7
	local xmin = cx + 13
	local xmax = cx + 38
	local ymin = cy - 4
	local ymax = cy + 16
	local xmindraw = 24
	local xmaxdraw = 39
	local ymindraw = 1
	local ymaxdraw = 16
	local drawx = 0
	local drawy = 0
	local drawwidth = 0
	local drawheight = 0
	local imgx = 0
	local imgy = 0
		
	drawx = realx
	drawy = realy
	
	if drawx <= xmindraw then
		imgx = xmindraw - realx
	elseif drawx > xmindraw then
		imgx = 0
	end
	
	if drawy <= ymindraw + 8 then
		imgy = ymindraw - realy
	elseif drawy > ymindraw + 8 then
		imgy = 0
	end
	
	if imgx < 0 then
		imgx = 0
	end
	
	if imgy < 0 then
		imgy = 0
	end
	
	if drawx <= xmindraw then
		drawwidth = realendx - xmindraw
	elseif drawx > xmindraw then
		drawwidth = xmaxdraw - realx
	end
	
	if drawy <= ymindraw + 8 then
		drawheight = realendy - ymindraw
	elseif drawy > ymindraw + 8 then
		drawheight = ymaxdraw - realx
	end
	
	if drawwidth > 15 then
		drawwidth = 15
	elseif drawwidth < 0 then
		drawwidth = 0
	end
	
	if drawheight > 7 then
		drawheight = 7
	elseif drawheight < 0 then
		drawheight = 0
	end

	if imageinitialized("carrierimg") then
		drawimagepart("carrierimg", drawx + imgx, drawy + imgy, imgx, imgy, drawwidth, drawheight)
		print("draw at x = " .. drawx .. ", y = " .. drawy .. ", xoffset = " .. imgx .. ", yoffset = " .. imgy .. ", width = " .. drawwidth .. ", height = " .. drawheight)
	end
end]]--

function drawimg()
	-- Get object x and y, camera x and y, and the object's image's height and width.
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	local imgwidth = getimagewidth("carrierimg")
	local imgheight = getimageheight("carrierimg")
	-- Calculate the object's x and y in relation to the camera so that we have a reference on where to draw the image. The draw function takes values in relation to the camera's position so if we give it the map position,
	-- there is the potential for drawing the image offscreen if the map is larger than the camera.
	local realx = x - cx
	local realy = y - cy
	-- Calculate where the end of the image is in relation to the camera.
	local realendx = realx + 15
	local realendy = realy + 7
	-- Set the bounds for where the image can be drawn on screen. This is the bounding box for the "port" through which you can see the map.
	local xmindraw = 24
	local xmaxdraw = 39
	local ymindraw = 1
	local ymaxdraw = 16
	-- Calculate the height and width of the draw area using the bounding box.
	local drawareawidth = xmaxdraw - xmindraw
	local drawareaheight = ymaxdraw - ymindraw
	-- Calculate how far from the bounding box we need to be before we need to stop reducing the width of the image and start changing the part_x and part_y variables.
	local xdrawmod = drawareawidth - imgwidth
	local ydrawmod = drawareaheight - imgheight
	-- Initialize variables that will be used later.
	local drawwidth, drawheight, imgx, imgy
	
	-- If the object's x position in relation to the camera is less than the point where we change how we calculate what to draw.
	if realx <= xmindraw + xdrawmod then
		-- Calculate how much of the image's width to cut off.
		imgx = xmindraw - realx
		-- Calculate how far we're going to draw on the image.
		drawwidth = realendx - xmindraw
	-- Else if the object's x position is less than said point.
	elseif realx > xmindraw + xdrawmod then
		-- We don't cut any of the image's width off.
		imgx = 0
		-- Calculate how far we're going to draw on the image.
		drawwidth = xmaxdraw - realx
	end
	
	-- If the object's y position in relation to the camera is less than the point where we change how we calculate what to draw.
	if realy <= ymindraw + ydrawmod then
		-- Calculate how much of the image's height to cut off.
		imgy = ymindraw - realy
		-- Calculate how far we're going to draw on the image.
		drawheight = realendy - ymindraw
	-- Else if the object's y position is less than said point.
	elseif realy > ymindraw + ydrawmod then
		-- We don't cut any of the image's height off.
		imgy = 0
		-- Calculate how far we're going to draw on the image.
		drawheight = ymaxdraw - realy
	end
	
	-- If our top-left corner for the image's x position is less than 0.
	if imgx < 0 then
		-- Set the top-left corner's x position to 0.
		imgx = 0
	end
	
	-- If our top-left corner for the image's y position is less than 0.
	if imgy < 0 then
		-- Set the top-left corner's x position to 0.
		imgy = 0
	end
	
	-- If we're set to draw more than all of the image's width.
	if drawwidth > imgwidth then
		-- Set it so we only draw the image's full width.
		drawwidth = imgwidth
	-- Else if we're set to draw less than none of the image's width.
	elseif drawwidth < 0 then
		-- Set it so we draw none of the image's width.
		drawwidth = 0
	end
	
	-- If we're set to draw more than all of the image's width.
	if drawheight > imgheight then
		-- Set it so we only draw the image's full width.
		drawheight = imgheight
	-- Else if we're set to draw less than none of the image's width.
	elseif drawheight < 0 then
		-- Set it so we draw none of the image's width.
		drawheight = 0
	end
	
	-- Calculate the position to draw the image in relation to how much of the image is being drawn on the left side.
	drawx = realx + imgx
	drawy = realy + imgy

	-- If our image is initialized.
	if imageinitialized("carrierimg") then
		-- Draw the part of the image we calculated.
		drawimagepart("carrierimg", drawx, drawy, imgx, imgy, drawwidth, drawheight)
	end
end