function runonce()
	setcameramap("title")
	setcamerax(0)
	setcameray(0)
	
	local up, down = 38, 40
	
	entitybindkey(this, "moveup", up, 0, -1)
	entitybindkey(this, "movedown", down, 0, -1)
	entitybindkey(this, "select", 13, 0, -1)
	entitybindkey(this, "speedup", 69, 0, -1)
	entitybindkey(this, "speeddown", 81, 0, -1)
	entitybindkey(this, "depthup", 87, 0, -1)
	entitybindkey(this, "depthdown", 83, 0, -1)
	entitybindkey(this, "headingclockwise", 68, 0, -1)
	entitybindkey(this, "headingcounter", 65, 0, -1)
	entitybindkey(this, "torp1", 49, 0, -1)
	entitybindkey(this, "torp2", 50, 0, -1)
	entitybindkey(this, "torp3", 51, 0, -1)
	entitybindkey(this, "torp4", 52, 0, -1)
end

function initialized()
	hull = 99
	crew = 99
	air = 99
	fuel = 99
	fueltimer = 50
	permdmg = 0
	-- firedmg = 0
	heading = 0
	-- datasave(pdir, 0)
	spd = 0
	depth = 0
	lost = false
	torp = ""
	--torpedo1 = true
	torp1timer = 0
	--torpedo2 = true
	torp2timer = 0
	--torpedo3 = true
	torp3timer = 0
	--torpedo4 = true
	torp4timer = 0
	movetimer = 10
	crewtimer = 60
	shottimer = 0
	airtimer = 3
	crewairtimer = 5
	winmessage = false
	cc = 0
	datasave("cc", cc)
	mission = dataread("mission")
	print("mission" .. tostring(mission))
	if mission == 0 then
		datasave(tostring(cc), "ELIMINATE")
		print(dataread(cc))
		datasave(tostring(cc) .. "sym", 19)
		cc = cc + 1
		datasave("cc", cc)
		print("mission confirmed" .. cc)
	elseif mission == 1 then
		datasave(tostring(cc), "TARGET")
		datasave(tostring(cc) .. "sym", 19)
		cc = cc + 1
		datasave("cc", cc)
	elseif mission == 2 then
		datasave(tostring(cc), "CAPTURE")
		datasave(tostring(cc) .. "sym", 19)
		cc = cc + 1
		datasave("cc", cc)
	end
	entityshow(this)
	local map = getentitymap(this)
	local cx = getentityx(this) - 31
	local cy = getentityy(this) - 9
	if map == "testmap1" or map == "testmap2" or map == "testmap3" then
		setentitytilechar(this, 24)
		setcamerax(cx)
		setcameray(cy)
		checktile()
		hud()
	end
	if map == "title" then
		setentitytilechar(this, 0)
		setcamerax(0)
		setcameray(0)
	end
end

function always()
	--[[local map = getentitymap(this)
	local entptr = mapptr(map)
	local test1ptr = mapptr("testmap1")
	local test2ptr = mapptr("testmap2")
	local titleptr = mapptr("title")
	-- local cx = getentityx(this) - 31
	-- local cy = getentityy(this) - 9
	if entptr == test1ptr or entptr == test2ptr then
		cc = dataread("cc")
		-- setcamerax(cx)
		-- setcameray(cy)
		camera()
		hitcheck()
		statuscheck()
		aircheck()
		firecheck()
		enemycheck()
		shallowcheck()
		checktile()
		hud()
		torptimercheck()
		move()
		boundcheck()
		wincheck()
	elseif entptr == titleptr then
		setcamerax(0)
		setcameray(0)
	end
	if spd == 0 then
		movetimer = 10
	end]]--
end

function main()
	local map = getentitymap(this)
	local entptr = mapptr(map)
	local test1ptr = mapptr("testmap1")
	local test2ptr = mapptr("testmap2")
	local test3ptr = mapptr("testmap3")
	local titleptr = mapptr("title")
	-- local cx = getentityx(this) - 31
	-- local cy = getentityy(this) - 9
	if (entptr == test1ptr or entptr == test2ptr or entptr == test3ptr) and lost == false then
		cc = dataread("cc")
		-- setcamerax(cx)
		-- setcameray(cy)
		camera()
		hitcheck()
		statuscheck()
		aircheck()
		fuelcheck()
		capturecheck()
		enemycheck()
		shallowcheck()
		checktile()
		hud()
		torptimercheck()
		move()
		boundcheck()
		wincheck()
	elseif entptr == titleptr then
		setcamerax(0)
		setcameray(0)
	end
	if spd == 0 then
		movetimer = 10
	end
	if lost == true then
		setgamestate(1)
	end
end

function moveup()
	local state = getgamestate()
	if state == pausedstate then
		pausemenuscroll(-1)
	end
end

function movedown()
	local state = getgamestate()
	if state == pausedstate then
		pausemenuscroll(1)
	end
end

function select()
	local state = getgamestate()
	if state == pausedstate then
		pausemenudo()
	end
end

function speedup()
	if spd == 0 then
		spd = spd + 1
	elseif spd < 2 and spd > 0 and depth > 0 then
		spd = spd + 1
	end
end

function speeddown()
	if spd > 0 then
		spd = spd - 1
	end
end

function depthup()
	if depth > 0 then
		depth = depth - 1
		setentitylayer(this, depth)
	end
end

function depthdown()
	if depth < 3 then
		depth = depth + 1
		setentitylayer(this, depth)
	end
end

function headingclockwise()
	if heading < 3 then
		heading = heading + 1
	elseif heading == 3 then
		heading = 0
	end
	-- datasave(pdir, heading)
end

function headingcounter()
	if heading > 0 then
		heading = heading - 1
	elseif heading == 0 then
		heading = 3
	end
	-- datasave(pdir, heading)
end

function torp1()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	local exists = entityexists("Torpedo1")
	
	if torp1timer <= 0 and shottimer <= 0 and exists == false then
		torp = entitycreate("PlayerTorpedo", x, y, getentitymap(this))
		setentityscript(torp, "root:scripts/playertorp.lua")
		initentityscript(torp)
		setentitytile(torp, 7, 1, 142)
		entityhandleadd(torp, "Torpedo1")
		entitydatasave("Torpedo1", "dir", heading)
		entitydatasave("Torpedo1", "layer", layer)
		if entityexists("Torpedo1") then
			datasave(tostring(cc), "TORPEDO 1 FIRED")
			datasave(tostring(cc) .. "sym", 33)
			cc = cc + 1
			datasave("cc", cc)
		end
		shottimer = 10
		torp1timer = 150
		--torpedo1 = false
	end
end

function torp2()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	local exists = entityexists("Torpedo2")
	
	if torp2timer <= 0 and shottimer <= 0 and exists == false then
		torp = entitycreate("PlayerTorpedo", x, y, getentitymap(this))
		setentityscript(torp, "root:scripts/playertorp.lua")
		initentityscript(torp)
		setentitytile(torp, 7, 1, 142)
		entityhandleadd(torp, "Torpedo2")
		entitydatasave("Torpedo2", "dir", heading)
		entitydatasave("Torpedo2", "layer", layer)
		if entityexists("Torpedo2") then
			datasave(tostring(cc), "TORPEDO 2 FIRED")
			datasave(tostring(cc) .. "sym", 33)
			cc = cc + 1
			datasave("cc", cc)
		end
		shottimer = 10
		torp2timer = 150
		--torpedo2 = false
	end
end

function torp3()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	local exists = entityexists("Torpedo3")
	
	if torp3timer <= 0 and shottimer <= 0 and exists == false then
		torp = entitycreate("PlayerTorpedo", x, y, getentitymap(this))
		setentityscript(torp, "root:scripts/playertorp.lua")
		initentityscript(torp)
		setentitytile(torp, 7, 1, 142)
		entityhandleadd(torp, "Torpedo3")
		entitydatasave("Torpedo3", "dir", heading)
		entitydatasave("Torpedo3", "layer", layer)
		if entityexists("Torpedo3") then
			datasave(tostring(cc), "TORPEDO 3 FIRED")
			datasave(tostring(cc) .. "sym", 33)
			cc = cc + 1
			datasave("cc", cc)
		end
		shottimer = 10
		torp3timer = 150
		--torpedo3 = false
	end
end

function torp4()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	local exists = entityexists("Torpedo4")
	
	if torp4timer <= 0 and shottimer <= 0 and exists == false then
		torp = entitycreate("PlayerTorpedo", x, y, getentitymap(this))
		setentityscript(torp, "root:scripts/playertorp.lua")
		initentityscript(torp)
		setentitytile(torp, 7, 1, 142)
		entityhandleadd(torp, "Torpedo4")
		entitydatasave("Torpedo4", "dir", heading)
		entitydatasave("Torpedo4", "layer", layer)
		if entityexists("Torpedo4") then
			datasave(tostring(cc), "TORPEDO 4 FIRED")
			datasave(tostring(cc) .. "sym", 33)
			cc = cc + 1
			datasave("cc", cc)
		end
		shottimer = 10
		torp4timer = 150
		--torpedo4 = false
	end
end

function camera()
	-- old xmax = 1 / old ymax = 23
	local cx = getentityx(this) - 31
	local cy = getentityy(this) - 9
	local cxmax = getmapwidth(getentitymap(this)) - 39
	local cymax = getmapheight(getentitymap(this)) - 17
	
	--[[if cx < -24 then
		cx = -24
	elseif cx > cxmax - 39 then
		cx = cxmax - 39
	end
	if cy < -1 then
		cy = -1
	elseif cy > cymax - 17 then
		cy = cymax - 17
	end]]--
	
	if cx < -24 then
		cx = -24
	elseif cx > cxmax then
		cx = cxmax
	end
	if cy < -1 then
		cy = -1
	elseif cy > cymax then
		cy = cymax
	end
	
	setcamerax(cx)
	setcameray(cy)
	--print(cx .. "," .. cy)
end

function move()
	local x = getentityx(this)
	local y = getentityy(this)
	if (movetimer <= 0 and spd > 0) then
		if heading == 0 then
			-- move(0 -1)
			entityposition(this, x, y - 1)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 1 then
			-- move(1, 0)
			entityposition(this, x + 1, y)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 2 then
			-- move(0, 1)
			entityposition(this, x, y + 1)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 3 then
			-- move(-1, 0)
			entityposition(this, x - 1, y)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		end
	else
		if spd > 0 then
			movetimer = movetimer - 1
		end
	end
	
	if spd > 1 and depth == 0 then
		spd = 1
	end
end

function hitcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "EnemyTorpedo" then
			local ex, ey = getentityxy(ptr)
			local elayer = getentitylayer(ptr)
			if ex == x and ey == y and elayer == layer then
				local dmg = 25 + random(-5, 5)
				local crewdmg = dmg - random(10, 15)
				hull = hull - dmg
				permdmg = permdmg + (dmg / 2)
				crew = crew - crewdmg
				datasave(tostring(cc), "WE'VE BEEN HIT")
				datasave(tostring(cc) .. "sym", 15)
				cc = cc + 1
				datasave("cc", cc)
				entitydestroy(ptr)
				--print(hull)
			end
		end
	end
end

function statuscheck()
	--if hull <= 0 or crew <= 0 or air <= 0 then
		--gameterminate()
		--[[local ent = getmapentities(getentitymap(this))
		local i, ptr
		local map = getentitymap(this)
	
		for i, ptr in ipairs(ent) do
			if getentityname(ptr) ~= "Player" then
				entitydestroy(ptr)
			end
		end
		initializemap("title")
		setentitymap("Player", "title")
		setcameramap("title")
		deinitializemap(map)]]--
	--end
	
	if hull < (99 - permdmg) then
		hull = hull + ((crew / 990) * (crew / 99))
	end
	
	if hull <= 0 and lost == false then
		hull = 0
		datasave(tostring(cc), "WE SANK")
		datasave(tostring(cc) .. "sym", 247)
		cc = cc + 1
		datasave("cc", cc)
		lost = true
		entityhide(this)
	end
	
	if crew <= 0 and lost == false then
		crew = 0
		datasave(tostring(cc), "OUR CREW ARE DEAD")
		datasave(tostring(cc) .. "sym", 19)
		cc = cc + 1
		datasave("cc", cc)
		lost = true
		entityhide(this)
	end
	
	if fuel <= 0 and lost == false then
		fuel = 0
		datasave(tostring(cc), "OUT OF FUEL")
		datasave(tostring(cc) .. "sym", 69)
		cc = cc + 1
		datasave("cc", cc)
		lost = true
		entityhide(this)
	end
	
	if hull <= 40 then
		if crewtimer <= 0 then
			crew = crew - 2
			crewtimer = 60
		else
			crewtimer = crewtimer - 1
		end
	end
	
	if air <= 0 then
		air = 0
		if crewairtimer <= 0 then
			crew = crew - 1
			crewairtimer = 5
		else
			crewairtimer = crewairtimer - 1
		end
	end
end

function aircheck()
	local airmod = (crew / 99) / 2
	local airrec = 1 - (airmod / 2)
	
	if air > 99 then
		air = 99
	end
	
	if air < 0 then
		air = 0
	end
	
	if depth > 0 then
		if airtimer <= 0 then
			if air > 0 then
				air = air - airmod
			end
			airtimer = 3
		else
			airtimer = airtimer - 1
		end
	else
		if airtimer <= 0 then
			if air < 99 then
				air = air + airrec
			end
			airtimer = 3
		else
			airtimer = airtimer - 1
		end
	end
end

function fuelcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	if fueltimer <= 0 then
		fuel = fuel - 1
		fueltimer = 50
	else
		fueltimer = fueltimer - 1
	end
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "Fuel" then
			local ex, ey = getentityxy(ptr)
			if ex == x and ey == y then
				fuel = 99
				entitydestroy(ptr)
			end
		end
	end
end

function capturecheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "Capture" then
			local ex, ey = getentityxy(ptr)
			if ex == x and ey == y then
				datasave(tostring(cc), "POINT CAPTURED")
				datasave(tostring(cc) .. "sym", 33)
				cc = cc + 1
				datasave("cc", cc)
				entitydestroy(ptr)
			end
		end
	end
end
	
function boundcheck()
	-- print("Beginning of bound check")
	local x = getentityx(this)
	local y = getentityy(this)
	local xmax = getmapwidth(getentitymap(this))
	local ymax = getmapheight(getentitymap(this))
	
	if x > xmax then
		setentityx(this, xmax)
		spd = 0
	elseif x < 0 then
		setentityx(this, 0)
		spd = 0
	end
	
	if y > ymax then
		setentityy(this, ymax)
		spd = 0
	elseif y < 0 then
		setentityy(this, 0)
		spd = 0
	end
	-- print("End of bound check")
end

function shallowcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local char, fg, bg = getmaptile(getentitymap(this), x, y, 1)
	
	if (char == 176 or char == 177 or char == 178) and depth > 0 then
		local dmg = 10 + random(-5, 5)
		local crewdmg = dmg - random(5, 10)
		hull = hull - dmg
		permdmg = permdmg + (dmg / 2)
		crew = crew - crewdmg
		datasave(tostring(cc), "HIT SHALLOW WATER")
		datasave(tostring(cc) .. "sym", 33)
		cc = cc + 1
		datasave("cc", cc)
		depth = 0
		setentitylayer(this, depth)
		print("depth = " .. depth)
	end
end

function checktile()
	if heading == 0 then
		setentitytilechar(this, 24)
	elseif heading == 1 then
		setentitytilechar(this, 26)
	elseif heading == 2 then
		setentitytilechar(this, 25)
	elseif heading == 3 then
		setentitytilechar(this, 27)
	end
end

function torptimercheck()
	if torp1timer <= 0 then
		torpedo1 = true
	else
		torp1timer = torp1timer - 1
	end
	
	if torp2timer <= 0 then
		torpedo2 = true
	else
		torp2timer = torp2timer - 1
	end
	
	if torp3timer <= 0 then
		torpedo3 = true
	else
		torp3timer = torp3timer - 1
	end
	
	if torp4timer <= 0 then
		torpedo4 = true
	else
		torp4timer = torp4timer - 1
	end
	
	if shottimer > 0 then
		shottimer = shottimer - 1
	end
end

function enemycheck()
	local x = getentityx(this)
	local y = getentityy(this)
	
	if entityexists("Sub") == true then
		local ent = getmapentities(getentitymap(this))
		local i, ptr
		for i, ptr in ipairs(ent) do
			-- print(tostring(ptr) .. " selected.")
			if getentityname(ptr) == "Sub" or getentityname(ptr) == "Ship" then
				-- print(tostring(ptr) .. "Is enemy")
				if entitydataread(ptr, "seen") ~= 1 then
					-- print(tostring(ptr) .. "Not seen")
					local ex, ey = getentityxy(ptr)
					if math.abs(ex - x) <= 7 and math.abs(ey - y) <= 7 then
						print(tostring(ptr) .. "In range")
						datasave(tostring(cc), "ENEMY SIGHTED")
						datasave(tostring(cc) .. "sym", 33)
						cc = cc + 1
						datasave("cc", cc)
						entitydatasave(ptr, "seen", 1)
						print(tostring(ptr) .. "Enemy sighted")
					end
				end
			end
		end
	end
end

function wincheck()
	if dataread("mission") == 0 and entityexists("Sub") == false and entityexists("Ship") == false and winmessage == false then
		datasave(tostring(cc), "MISSION COMPLETE")
		datasave(tostring(cc) .. "sym", 251)
		cc = cc + 1
		datasave("cc", cc)
		winmessage = true
	elseif dataread("mission") == 1 and entityexists("Target") == false and winmessage == false then
		datasave(tostring(cc), "MISSION COMPLETE")
		datasave(tostring(cc) .. "sym", 251)
		cc = cc + 1
		datasave("cc", cc)
		winmessage = true
	elseif dataread("mission") == 2 and entityexists("Capture") == false and winmessage == false then
		datasave(tostring(cc), "MISSION COMPLETE")
		datasave(tostring(cc) .. "sym", 251)
		cc = cc + 1
		datasave("cc", cc)
		winmessage = true
	end
end

function hud()
	drawset(201, 1, 142)
	drawtile(0, 0)
	drawset(187, 1, 142)
	drawtile(39, 0)
	drawset(188, 1, 142)
	drawtile(39, 39)
	drawset(200, 1, 142)
	drawtile(0, 39)
	drawset(205, 1, 142)
	drawline(1, 0, 22, 0)
	drawline(24, 0, 38, 0)
	drawline(1, 17, 11, 17)
	drawline(13, 17, 22, 17)
	drawline(24, 17, 38, 17)
	drawline(1, 30, 11, 30)
	drawline(13, 30, 23, 30)
	drawline(25, 30, 38, 30)
	drawline(1, 39, 11, 39)
	drawline(13, 39, 23, 39)
	drawline(25, 39, 38, 39)
	drawset(186, 1, 142)
	drawline(0, 1, 0, 16)
	drawline(23, 1, 23, 16)
	drawline(39, 1, 39, 16)
	drawline(0, 18, 0, 29)
	drawline(12, 18, 12, 29)
	drawline(39, 18, 39, 29)
	drawline(0, 31, 0, 38)
	drawline(12, 31, 12, 38)
	drawline(24, 31, 24, 38)
	drawline(39, 31, 39, 38)
	drawset(203, 1, 142)
	drawtile(23, 0)
	drawtile(12, 17)
	drawtile(24, 30)
	drawset(202, 1, 142)
	drawtile(23, 17)
	drawtile(12, 39)
	drawtile(24, 39)
	drawset(185, 1, 142)
	drawtile(39, 17)
	drawtile(39, 30)
	drawset(204, 1, 142)
	drawtile(0, 17)
	drawtile(0, 30)
	drawset(206, 1, 142)
	drawtile(12, 30)
	drawset(0, 1, 142)
	fillrect(1, 1, 22, 16)
	fillrect(1, 18, 11, 12)
	fillrect(13, 18, 26, 12)
	fillrect(1, 31, 11, 8)
	fillrect(13, 31, 11, 8)
	fillrect(25, 31, 14, 8)
	drawtext(6, 3, "CAPTAINS LOG")
	drawtext(4, 20, "DEPTH")
	drawtext(23, 20, "STATUS")
	drawtext(15, 22, "HULL")
	drawtext(30, 22, "CREW")
	drawtext(15, 26, "AIR")
	drawtext(30, 26, "FUEL")
	drawtext(3, 33, "HEADING")
	drawtext(16, 33, "SPEED")
	drawtext(29, 33, "TORPS.")
	
	-- drawset(0, 142, 1)
	--[[if dataexists(tostring(cc)) == true then
		-- drawset(0, 142, 1)
		-- drawtile(4, 14)
		drawtext(5, 15, dataread(cc))
	end]]--
	
	-- drawset(0, 1, 142)
	
	if dataexists(tostring(cc-1)) == true then
		drawset(0, 142, 1)
		drawtile(4, 14)
		drawtext(5, 14, dataread(cc-1))
	end
	
	drawset(0, 1, 142)
	
	if dataexists(tostring(cc-2)) == true then
		drawtext(5, 13, dataread(cc-2))
	end
	if dataexists(tostring(cc-3)) == true then
		drawtext(5, 12, dataread(cc-3))
	end
	if dataexists(tostring(cc-4)) == true then
		drawtext(5, 11, dataread(cc-4))
	end
	if dataexists(tostring(cc-5)) == true then
		drawtext(5, 10, dataread(cc-5))
	end
	if dataexists(tostring(cc-6)) == true then
		drawtext(5, 9, dataread(cc-6))
	end
	if dataexists(tostring(cc-7)) == true then
		drawtext(5, 8, dataread(cc-7))
	end
	if dataexists(tostring(cc-8)) == true then
		drawtext(5, 7, dataread(cc-8))
	end
	if dataexists(tostring(cc-9)) == true then
		drawtext(5, 6, dataread(cc-9))
	end
	
	--[[if dataexists(tostring(cc) .. "sym") == true then
		drawset(dataread(tostring(cc) .. "sym"), 142, 1)
		drawtile(3, 14)
	end]]--
	if dataexists(tostring(cc-1) .. "sym") == true then
		drawset(dataread(tostring(cc-1) .. "sym"), 142, 1)
		drawtile(3, 14)
	end
	if dataexists(tostring(cc-2) .. "sym") == true then
		drawset(dataread(tostring(cc-2) .. "sym"), 1, 142)
		drawtile(3, 13)
	end
	if dataexists(tostring(cc-3) .. "sym") == true then
		drawset(dataread(tostring(cc-3) .. "sym"), 1, 142)
		drawtile(3, 12)
	end
	if dataexists(tostring(cc-4) .. "sym") == true then
		drawset(dataread(tostring(cc-4) .. "sym"), 1, 142)
		drawtile(3, 11)
	end
	if dataexists(tostring(cc-5) .. "sym") == true then
		drawset(dataread(tostring(cc-5) .. "sym"), 1, 142)
		drawtile(3, 10)
	end
	if dataexists(tostring(cc-6) .. "sym") == true then
		drawset(dataread(tostring(cc-6) .. "sym"), 1, 142)
		drawtile(3, 9)
	end
	if dataexists(tostring(cc-7) .. "sym") == true then
		drawset(dataread(tostring(cc-7) .. "sym"), 1, 142)
		drawtile(3, 8)
	end
	if dataexists(tostring(cc-8) .. "sym") == true then
		drawset(dataread(tostring(cc-8) .. "sym"), 1, 142)
		drawtile(3, 7)
	end
	if dataexists(tostring(cc-9) .. "sym") == true then
		drawset(dataread(tostring(cc-9) .. "sym"), 1, 142)
		drawtile(3, 6)
	end
	
	if keydown(65) then
		drawset(27, 142, 1)
	else
		drawset(27, 1, 142)
	end
	drawtile(3, 36)
	
	if keydown(68) then
		drawset(26, 142, 1)
	else
		drawset(26, 1, 142)
	end
	drawtile(9, 36)
	
	if heading == 0 then
		drawset(78, 1, 142)
	elseif heading == 1 then
		drawset(69, 1, 142)
	elseif heading == 2 then
		drawset(83, 1, 142)
	elseif heading == 3 then
		drawset(87, 1, 142)
	end
	drawtile(6, 36)
	
	if keydown(81) then
		drawset(27, 142, 1)
	else
		drawset(27, 1, 142)
	end
	drawtile(15, 36)
	
	if keydown(69) then
		drawset(26, 142, 1)
	else
		drawset(26, 1, 142)
	end
	drawtile(21, 36)
	
	drawset(219, 1, 142)
	drawline(17, 36, 19, 36)
	
	drawset(8, 1, 142)
	if spd == 0 then
		drawtile(17, 36)
	elseif spd == 1 then
		drawtile(18, 36)
	elseif spd == 2 then
		drawtile(19, 36)
	end
	
	if keydown(87) then
		drawset(24, 142, 1)
	else
		drawset(24, 1, 142)
	end
	drawtile(6, 22)
	
	if keydown(83) then
		drawset(25, 142, 1)
	else
		drawset(25, 1, 142)
	end
	drawtile(6, 27)
	
	drawset(219, 1, 142)
	drawline(6, 23, 6, 26)
	
	drawset(8, 1, 142)
	if depth == 0 then
		drawtile(6, 23)
	elseif depth == 1 then
		drawtile(6, 24)
	elseif depth == 2 then
		drawtile(6, 25)
	elseif depth == 3 then
		drawtile(6, 26)
	end
	
	drawtext(20, 22, math.floor(hull))
	drawtext(35, 22, crew)
	drawtext(20, 26, math.floor(air))
	drawtext(35, 26, fuel)
	
	if hull < 20 then
		drawset(219, 1, 142)
		drawtile(16, 24)
		drawset(176, 1, 142)
		drawline(17, 24, 20, 24)
	elseif (hull >= 20 and hull < 40) then
		drawset(219, 1, 142)
		drawline(16, 24, 17, 24)
		drawset(176, 1, 142)
		drawline(18, 24, 20, 24)
	elseif (hull >= 40 and hull < 60) then
		drawset(219, 1, 142)
		drawline(16, 24, 18, 24)
		drawset(176, 1, 142)
		drawline(19, 24, 20, 24)
	elseif (hull >= 60 and hull < 80) then
		drawset(219, 1, 142)
		drawline(16, 24, 19, 24)
		drawset(176, 1, 142)
		drawtile(20, 24)
	elseif hull >= 80 then
		drawset(219, 1, 142)
		drawline(16, 24, 20, 24)
	end
	
	if crew < 20 then
		drawset(219, 1, 142)
		drawtile(31, 24)
		drawset(176, 1, 142)
		drawline(32, 24, 35, 24)
	elseif (crew >= 20 and crew < 40) then
		drawset(219, 1, 142)
		drawline(31, 24, 32, 24)
		drawset(176, 1, 142)
		drawline(33, 24, 35, 24)
	elseif (crew >= 40 and crew < 60) then
		drawset(219, 1, 142)
		drawline(31, 24, 33, 24)
		drawset(176, 1, 142)
		drawline(34, 24, 35, 24)
	elseif (crew >= 60 and crew < 80) then
		drawset(219, 1, 142)
		drawline(31, 24, 34, 24)
		drawset(176, 1, 142)
		drawtile(35, 24)
	elseif crew >= 80 then
		drawset(219, 1, 142)
		drawline(31, 24, 35, 24)
	end
	
	if air < 20 then
		drawset(219, 1, 142)
		drawtile(16, 28)
		drawset(176, 1, 142)
		drawline(17, 28, 20, 28)
	elseif (air >= 20 and air < 40) then
		drawset(219, 1, 142)
		drawline(16, 28, 17, 28)
		drawset(176, 1, 142)
		drawline(18, 28, 20, 28)
	elseif (air >= 40 and air < 60) then
		drawset(219, 1, 142)
		drawline(16, 28, 18, 28)
		drawset(176, 1, 142)
		drawline(19, 28, 20, 28)
	elseif (air >= 60 and air < 80) then
		drawset(219, 1, 142)
		drawline(16, 28, 19, 28)
		drawset(176, 1, 142)
		drawtile(20, 28)
	elseif air >= 80 then
		drawset(219, 1, 142)
		drawline(16, 28, 20, 28)
	end
	
	if fuel < 20 then
		drawset(219, 1, 142)
		drawtile(31, 28)
		drawset(176, 1, 142)
		drawline(32, 28, 35, 28)
	elseif (fuel >= 20 and fuel < 40) then
		drawset(219, 1, 142)
		drawline(31, 28, 32, 28)
		drawset(176, 1, 142)
		drawline(33, 28, 35, 28)
	elseif (fuel >= 40 and fuel < 60) then
		drawset(219, 1, 142)
		drawline(31, 28, 33, 28)
		drawset(176, 1, 142)
		drawline(34, 28, 35, 28)
	elseif (fuel >= 60 and fuel < 80) then
		drawset(219, 1, 142)
		drawline(31, 28, 34, 28)
		drawset(176, 1, 142)
		drawtile(35, 28)
	elseif fuel >= 80 then
		drawset(219, 1, 142)
		drawline(31, 28, 35, 28)
	end
	
	if torp1timer <= 0 and entityexists("Torpedo1") == false then
		drawset(49, 1, 142)
		drawtile(27, 36)
	else
		drawset(49, 142, 1)
		drawtile(27, 36)
	end
	
	if torp2timer <= 0 and entityexists("Torpedo2") == false then
		drawset(50, 1, 142)
		drawtile(30, 36)
	else
		drawset(50, 142, 1)
		drawtile(30, 36)
	end
	
	if torp3timer <= 0 and entityexists("Torpedo3") == false then
		drawset(51, 1, 142)
		drawtile(33, 36)
	else
		drawset(51, 142, 1)
		drawtile(33, 36)
	end
	
	if torp4timer <= 0 and entityexists("Torpedo4") == false then
		drawset(52, 1, 142)
		drawtile(36, 36)
	else
		drawset(52, 142, 1)
		drawtile(36, 36)
	end
end