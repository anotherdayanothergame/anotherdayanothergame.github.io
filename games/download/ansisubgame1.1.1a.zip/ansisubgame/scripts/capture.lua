function runonce()

end

function initialized()
	setentitysolid(this, false)
	if entityissolid(this) == false then
		setentitytile(this, 67, 1, 142)
	end
end

function always()

end

function main()

end