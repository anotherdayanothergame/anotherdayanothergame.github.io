-- Placeholder text.

include "root:scripts/resetmap.lua"
function runonce()

end

function main()
	drawclear()
end

function menutestmap1()
	--local targetmap = mapptr("testmap1")
	if mapexists("testmap1") == true then
		resetmap()
		datasave("mission", 0)
		initializemap("testmap1")
		setcameramap("testmap1")
		setentitymap("Player", "testmap1")
		setentityx("Player", 7)
		setentityy("Player", 32)
		
		enemy = entitycreate("Sub", 30, 30, "testmap1")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)

		enemy2 = entitycreate("Sub", 1, 10, "testmap1")
		setentityscript(enemy2, "root:scripts/ai.lua")
		initentityscript(enemy2)

		enemy3 = entitycreate("Sub", 30, 3, "testmap1")
		setentityscript(enemy3, "root:scripts/ai.lua")
		initentityscript(enemy3)
		
		enemy4 = entitycreate("Sub", 9, 30, "testmap1")
		setentityscript(enemy4, "root:scripts/ai.lua")
		initentityscript(enemy4)
		
		ship = entitycreate("Ship", 5, 21, "testmap1")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		fuel = entitycreate("Fuel", 10, 30, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
		
		fuel = entitycreate("Fuel", 30, 10, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
	end
end

function menutestmap2()
	--local targetmap = mapptr(targetmap)
	if mapexists("testmap2") == true then
		resetmap()
		datasave("mission", 1)
		initializemap("testmap2")
		setcameramap("testmap2")
		setentitymap("Player", "testmap2")
		setentityx("Player", 6)
		setentityy("Player", 6)
		
		target = entitycreate("Target", 49, 5, "testmap2")
		setentityscript(target, "root:scripts/carrier.lua")
		initentityscript(target)
		
		enemy = entitycreate("Sub", 48, 6, "testmap2")
		setentityscript(enemy, "root:scripts/carrierguard.lua")
		initentityscript(enemy)
		
		enemy = entitycreate("Sub", 48, 8, "testmap2")
		setentityscript(enemy, "root:scripts/carrierguard.lua")
		initentityscript(enemy)
		
		enemy = entitycreate("Sub", 28, 2, "testmap2")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)
		
		ship = entitycreate("Ship", 26, 2, "testmap2")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 30, 2, "testmap2")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		fuel = entitycreate("Fuel", 27, 19, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
	end
end

function menutestmap3()
	if mapexists("testmap3") == true then
		resetmap()
		datasave("mission", 2)
		initializemap("testmap3")
		setcameramap("testmap3")
		setentitymap("Player", "testmap3")
		setentityx("Player", 9)
		setentityy("Player", 56)
		
		capture = entitycreate("Capture", 35, 46, "testmap3")
		setentityscript(capture, "root:scripts/capture.lua")
		initentityscript(capture)
		
		capture = entitycreate("Capture", 10, 10, "testmap3")
		setentityscript(capture, "root:scripts/capture.lua")
		initentityscript(capture)
		
		capture = entitycreate("Capture", 56, 4, "testmap3")
		setentityscript(capture, "root:scripts/capture.lua")
		initentityscript(capture)
		
		enemy = entitycreate("Sub", 4, 12, "testmap3")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)
		
		enemy = entitycreate("Sub", 30, 42, "testmap3")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)
		
		enemy = entitycreate("Sub", 31, 47, "testmap3")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)
		
		enemy = entitycreate("Sub", 40, 3, "testmap3")
		setentityscript(enemy, "root:scripts/ai.lua")
		initentityscript(enemy)
		
		ship = entitycreate("Ship", 9, 10, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 11, 10, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 41, 52, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 46, 44, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 42, 21, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		ship = entitycreate("Ship", 52, 33, "testmap3")
		setentityscript(ship, "root:scripts/ship.lua")
		initentityscript(ship)
		
		fuel = entitycreate("Fuel", 9, 28, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
		
		fuel = entitycreate("Fuel", 22, 12, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
		
		fuel = entitycreate("Fuel", 52, 37, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
		
		fuel = entitycreate("Fuel", 57, 3, "testmap1")
		setentityscript(fuel, "root:scripts/fueldepot.lua")
		initentityscript(fuel)
	end
end

function menuresume()
	setgamestate(0)
end

function menutitle()
	--map = getentitymap(player)
	initializemap("title")
	if mapexists("title") == true then
		if mapexists("testmap1") == true then
			if mapinitialized("testmap1")  == true then
				resetmap()
				deinitializemap("testmap1")
			end
		end
		if mapexists("testmap2") == true then
			if mapinitialized("testmap2")  == true then
				resetmap()
				deinitializemap("testmap2")
			end
		end
		if mapexists("testmap3") == true then
			if mapinitialized("testmap3")  == true then
				resetmap()
				deinitializemap("testmap3")
			end
		end
	end
	setentitytilechar("Player", 0)
	drawclear()
	setcameramap("title")
	setentitymap("Player", "title")
	setentityx("Player", 4)
	setentityy("Player", 4)
end

function menuresign()
	gameterminate()
end