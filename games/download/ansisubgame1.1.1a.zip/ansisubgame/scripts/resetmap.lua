function resetmap()
	map = getentitymap(player)
	if entityexists("Sub") == true or entityexists("Fuel") == true or entityexists("Capture") == true or entityexists("Ship") or entityexists("Target") then
		local ent = getmapentities(map)
		local i, ptr
		for i, ptr in ipairs(ent) do
			--if getentityname(ptr) == "Sub" or getentityname(ptr) == "Fuel" or getentityname(ptr) == "Capture" then
			if getentityname(ptr) ~= "Player" then
				entitydestroy(ptr)
			end
		end
	end
end