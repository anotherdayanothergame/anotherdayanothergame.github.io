function move()
	local x = getentityx(this)
	local y = getentityy(this)
	local px = getentityx(player)
	local py = getentityy(player)
	local diffx = math.abs(px - x)
	local diffy = math.abs(py - y)
	
	if (diffx < diffy and x ~= px) then
		if px > x then
			if movetimer <= 0 then
				entityposition(this, x + 1, y)
				movetimer = 60
			end
		elseif px < x then
			if movetimer <= 0 then
				entityposition(this, x - 1, y)
				movetimer = 60
			end
		end
	elseif (diffy < diffx and y ~= py) then
		if py > y then
			if movetimer <= 0 then
				entityposition(this, x, y + 1)
				movetimer = 60
			end
		elseif py < y then
			if movetimer <= 0 then
				entityposition(this, x, y - 1)
				movetimer = 60
			end
		end
	elseif (diffy < diffx and y == py) then
		if diffx > 4 then
			if px > x then
				if movetimer <= 0 then
					entityposition(this, x + 1, y)
					movetimer = 60
				end
			elseif px < x then
				if movetimer <= 0 then
					entityposition(this, x - 1, y)
					movetimer = 60
				end
			end
		end
	elseif (diffx < diffy and x == px) then
		if diffy > 4 then
			if py > y then
				if movetimer <= 0 then
					entityposition(this, x, y + 1)
					movetimer = 60
				end
			elseif py < y
				if movetimer <= 0 then
					entityposition(this, x, y - 1)
					movetimer = 60
				end
			end
		end
	elseif (x ~= px and y ~= py and diffx == diffy) then
		local rand = math.random(1, 10)
		
		if (rand <= 5) then
			if px > x then
				if movetimer <= 0 then
					entityposition(this, x + 1, y)
					movetimer = 60
				end
			elseif px < x then
				if movetimer <= 0 then
					entityposition(this, x - 1, y)
					movetimer = 60
				end
			end
		elseif (rand > 5) then
			if py > y then
				if movetimer <= 0 then
					entityposition(this, x, y + 1)
					movetimer = 60
				end
			elseif py < y then
				if movetimer <= 0 then
					entityposition(this, x, y - 1)
					movetimer = 60
				end
			end
		end
	end
end