-- Original
function move()
	local x = getentityx(this)
	local y = getentityy(this)
	if (movetimer <= 0 and spd > 0) then
		if heading == 0 then
			-- move(0 -1)
			entityposition(this, x, y - 1)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 1 then
			-- move(1, 0)
			entityposition(this, x + 1, y)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 2 then
			-- move(0, 1)
			entityposition(this, x, y + 1)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		elseif heading == 3 then
			-- move(-1, 0)
			entityposition(this, x - 1, y)
			if spd == 1 then
				movetimer = 60
			elseif spd == 2 then
				movetimer = 30
			end
		end
	else
		if spd > 0 then
			movetimer = movetimer - 1
		end
	end
	
	if spd > 1 and depth == 0 then
		spd = 1
	end
end

-- New
function move()
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	local tx, ty, tw, th
	
	if entityexists("Target") then
		tx = getentityx("Target")
		ty = getentityy("Target")
		tw = getentitywidth("Target")
		th = getentityheght("Target")
		if (movetimer <= 0 and spd > 0) then
			if heading == 0 then
				-- move(0 -1)
				if y - 1 > ty and y - 1 < th and x > tx and x < tx + tw then
					if getdrawntilefg(x - cx, y - cy - 1) == 255 then
						entityposition(this, x, y - 1)
					end
				else 
					entityposition(this, x, y - 1)
				end
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 1 then
				-- move(1, 0)
				if y > ty and y < th and x + 1 > tx and x + 1 < tx + tw then
					if getdrawntilefg(x - cx + 1, y - cy) == 255 then
						entityposition(this, x + 1, y)
					end
				else 
					entityposition(this, x + 1, y)
				end
				-- entityposition(this, x + 1, y)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 2 then
				-- move(0, 1)
				if y + 1 > ty and y + 1 < th and x > tx and x < tx + tw then
					if getdrawntilefg(x - cx, y - cy + 1) == 255 then
						entityposition(this, x, y + 1)
					end
				else 
					entityposition(this, x, y + 1)
				end
				-- entityposition(this, x, y + 1)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 3 then
				-- move(-1, 0)
				if y > ty and y < th and x - 1 > tx and x - 1 < tx + tw then
					if getdrawntilefg(x - cx - 1, y - cy) == 255 then
						entityposition(this, x - 1, y)
					end
				else 
					entityposition(this, x - 1, y)
				end
				-- entityposition(this, x - 1, y)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			end
		else
			if spd > 0 then
				movetimer = movetimer - 1
			end
		end
	else
		if (movetimer <= 0 and spd > 0) then
			if heading == 0 then
				-- move(0 -1)
				entityposition(this, x, y - 1)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 1 then
				-- move(1, 0)
				entityposition(this, x + 1, y)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 2 then
				-- move(0, 1)
				entityposition(this, x, y + 1)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			elseif heading == 3 then
				-- move(-1, 0)
				entityposition(this, x - 1, y)
				if spd == 1 then
					movetimer = 60
				elseif spd == 2 then
					movetimer = 30
				end
			end
		else
			if spd > 0 then
				movetimer = movetimer - 1
			end
		end
	end
		
	if spd > 1 and depth == 0 then
		spd = 1
	end
end

function drawimg()
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	local imgwidth = getimagewidth("image")
	local imgheight = getimageheight("image")
	local realx = x - cx
	local realy = y - cy
	local realendx = realx + 15
	local realendy = realy + 7
	local xmin = cx + 13
	local xmax = cx + 38
	local ymin = cy - 4
	local ymax = cy + 16
	local xmindraw = 24
	local xmaxdraw = 39
	local ymindraw = 1
	local ymaxdraw = 16
	local drawareawidth = xmaxdraw - xmindraw
	local drawareaheight = ymaxdraw - ymindraw
	local xdrawmod = drawareawidth - imgwidth
	local ydrawmod = drawareaheight - imgheight
	local drawwidth, drawheight, imgx, imgy
	
	if drawx <= xmindraw + xdrawmod then
		imgx = xmindraw - realx
	elseif drawx > xmindraw + xdrawmod then
		imgx = 0
	end
	
	if drawy <= ymindraw + ydrawmod then
		imgy = ymindraw - realy
	elseif drawy > ymindraw + ydrawmod then
		imgy = 0
	end
	
	if imgx < 0 then
		imgx = 0
	end
	
	if imgy < 0 then
		imgy = 0
	end
	
	if drawx <= xmindraw + xdrawmod then
		drawwidth = realendx - xmindraw
	elseif drawx > xmindraw + xdrawmod then
		drawwidth = xmaxdraw - realx
	end
	
	if drawy <= ymindraw + ydrawmod then
		drawheight = realendy - ymindraw
	elseif drawy > ymindraw + ydrawmod then
		drawheight = ymaxdraw - realy
	end
	
	if drawwidth > imgwidth then
		drawwidth = imgwidth
	elseif drawwidth < 0 then
		drawwidth = 0
	end
	
	if drawheight > imgheight then
		drawheight = imgheight
	elseif drawheight < 0 then
		drawheight = 0
	end
	
	drawx = realx + imgx
	drawy = realy + imgy

	if imageinitialized("carrierimg") then
		drawimagepart("carrierimg", drawx, drawy, imgx, imgy, drawwidth, drawheight)
	end
end

function drawimg()
	-- Get object x and y, camera x and y, and the object's image's height and width.
	local x = getentityx(this)
	local y = getentityy(this)
	local cx = getcamerax()
	local cy = getcameray()
	local imgwidth = getimagewidth("carrierimg")
	local imgheight = getimageheight("carrierimg")
	-- Calculate the object's x and y in relation to the camera so that we have a reference on where to draw the image. The draw function takes values in relation to the camera's position so if we give it the map position,
	-- there is the potential for drawing the image offscreen if the map is larger than the camera.
	local realx = x - cx
	local realy = y - cy
	-- Calculate where the end of the image is in relation to the camera.
	local realendx = realx + 15
	local realendy = realy + 7
	-- Set the bounds for where the image can be drawn on screen. This is the bounding box for the "port" through which you can see the map.
	local xmindraw = 24
	local xmaxdraw = 39
	local ymindraw = 1
	local ymaxdraw = 16
	-- Calculate the height and width of the draw area using the bounding box.
	local drawareawidth = xmaxdraw - xmindraw
	local drawareaheight = ymaxdraw - ymindraw
	-- Calculate how far from the bounding box we need to be before we need to stop reducing the width of the image and start changing the part_x and part_y variables.
	local xdrawmod = drawareawidth - imgwidth
	local ydrawmod = drawareaheight - imgheight
	-- Initialize variables that will be used later.
	local drawwidth, drawheight, imgx, imgy
	
	-- If the object's x position in relation to the camera is less than the point where we change how we calculate what to draw.
	if realx <= xmindraw + xdrawmod then
		-- Calculate how much of the image's width to cut off.
		imgx = xmindraw - realx
	-- Else if the object's x position is less than said point.
	elseif realx > xmindraw + xdrawmod then
		-- We don't cut any of the image's width off.
		imgx = 0
	end
	
	-- If the object's y position in relation to the camera is less than the point where we change how we calculate what to draw.
	if realy <= ymindraw + ydrawmod then
		-- Calculate how much of the image's height to cut off.
		imgy = ymindraw - realy
	-- Else if the object's y position is less than said point.
	elseif realy > ymindraw + ydrawmod then
		-- We don't cut any of the image's height off.
		imgy = 0
	end
	
	-- If our top-left corner for the image's x position is less than 0.
	if imgx < 0 then
		-- Set the top-left corner's x position to 0.
		imgx = 0
	end
	
	-- If our top-left corner for the image's y position is less than 0.
	if imgy < 0 then
		-- Set the top-left corner's x position to 0.
		imgy = 0
	end
	
	
	if realx <= xmindraw + xdrawmod then
		drawwidth = realendx - xmindraw
	elseif realx > xmindraw + xdrawmod then
		drawwidth = xmaxdraw - realx
	end
	
	if realy <= ymindraw + ydrawmod then
		drawheight = realendy - ymindraw
	elseif realy > ymindraw + ydrawmod then
		drawheight = ymaxdraw - realy
	end
	
	if drawwidth > imgwidth then
		drawwidth = imgwidth
	elseif drawwidth < 0 then
		drawwidth = 0
	end
	
	if drawheight > imgheight then
		drawheight = imgheight
	elseif drawheight < 0 then
		drawheight = 0
	end
	
	drawx = realx + imgx
	drawy = realy + imgy

	if imageinitialized("carrierimg") then
		drawimagepart("carrierimg", drawx, drawy, imgx, imgy, drawwidth, drawheight)
	end
end