include "root:scripts/hud.lua"

function runonce()
	local up, down = 38, 40
	heading = 0;
	speed = 0;
	depth = 0;
	torpedo1 = true;
	torpedo2 = true;
	torpedo3 = true;
	torpedo4 = true;
	
	entitybindkey(this, "moveup", up, 0, -1)
	entitybindkey(this, "movedown", down, 0, -1)
	entitybindkey(this, "select", 13, 0, -1)
	entitybindkey(this, "speedup", 69, 0, -1)
	entitybindkey(this, "speeddown", 81, 0, -1)
	entitybindkey(this, "depthup", 87, 0, -1)
	entitybindkey(this, "depthdown", 83, 0, -1)
	entitybindkey(this, "headingclockwise", 68, 0, -1)
	entitybindkey(this, "headingcounter", 65, 0, -1)
	entitybindkey(this, "torp1", 49, 0, -1)
	entitybindkey(this, "torp2", 50, 0, -1)
	entitybindkey(this, "torp3", 51, 0, -1)
	entitybindkey(this, "torp4", 52, 0, -1)
end

function initialized()
	local cx = getentityx(this) - 31
	local cy = getentityy(this) - 9
	setcamerax(cx)
	setcameray(cy)
end

function always()
	local cx = getentityx(this) - 31
	local cy = getentityy(this) - 9
	setcamerax(cx)
	setcameray(cy)
	checktile()
end

function main()

end

function speedup()
	speed = speed + 1
end

function speeddown()
	speed = speed - 1
end

function depthup()
	depth = depth - 1
end

function depthdown()
	depth = depth + 1
end

function headingclockwise()
	if heading < 3 then
		heading = heading + 1
	else if heading == 3 then
		heading = 0
	end
end

function headingcounter()
	if heading > 0 then
		heading = heading - 1
	else if heading == 0 then
		heading = 3
	end
end

function torp1()

end

function torp2()

end

function torp3()

end

function torp4()

end

function moveup()
	local state = getgamestate()
	if state == pausedstate then
		pausemenuscroll(-1)
	end
end

function movedown()
	local state = getgamestate()
	if state == pausedstate then
		pausemenuscroll(1)
	end
end

function select()
	local state = getgamestate()
	if state == pausedstate then
		pausemenudo()
	end
end

function checktile()
	if heading == 0 then
		setentitytilechar(this, 24)
	elseif heading == 1 then
		setentitytilechar(this, 26)
	elseif heading == 2 then
		setentitytilechar(this, 25)
	elseif heading == 4 then
		setentitytilechar(this, 27)
	end
end