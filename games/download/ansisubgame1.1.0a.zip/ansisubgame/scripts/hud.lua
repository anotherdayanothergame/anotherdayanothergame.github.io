function hud(entity)

end