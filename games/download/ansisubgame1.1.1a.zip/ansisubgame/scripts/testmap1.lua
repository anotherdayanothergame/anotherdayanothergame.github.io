function runonce()
	enemy = entitycreate("Enemy", 9, 30, "testmap1")
	setentityz(enemy, 1)
	enemy = entitycreate("Enemy", 4, 4, "testmap1")
	setentityz(enemy, 1)
	enemy = entitycreate("Enemy", 30, 16, "testmap1")
	setentityz(enemy, 1)
end