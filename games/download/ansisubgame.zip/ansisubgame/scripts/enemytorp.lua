function runonce()

end

function initialized()
	setentitylayer(this, 7)
	destroytimer = 1
	timer = 3
	layerset = false
	hit = false
	heading = entitydataread(this, "dir")
	layerread = entitydataread(this, "layer")
	-- print(heading)
end

function always()
	-- cc = dataread("cc")
	-- timer = timer - 1
	-- move()
	-- hitcheck()
	-- boundcheck()
	-- destroy()
end

function main()
	timer = timer - 1
	move()
	boundcheck()
end

function move()
	local x = getentityx(this)
	local y = getentityy(this)
	local layer = getentitylayer(this)
	
	if heading == 0 and timer <= 0 then
		--doaction(x, y - 1)
		setentityposition(this, x, y - 1)
		timer = 3
	elseif heading == 1 and timer <= 0 then
		--doaction(x + 1, y)
		setentityposition(this, x + 1, y)
		timer = 3
	elseif heading == 2 and timer <= 0 then
		--doaction(x, y + 1)
		setentityposition(this, x, y + 1)
		timer = 3
	elseif heading == 3 and timer <= 0 then
		--doaction(x - 1, y)
		setentityposition(this, x - 1, y)
		timer = 3
	elseif heading == nil then
		heading = entitydataread(this, "dir")
		-- print(heading)
	end
	
	if layerread ~= nil then
		setentitylayer(this, layerread)
	else
		layerread = entitydataread(this, "layer")
	end
end

function hitcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "Player" then
			local ex, ey = getentityxy(ptr)
			if ex == x and ey == y then
				datasave(tostring(cc), "WE'VE BEEN HIT")
				datasave(tostring(cc) .. "sym", 15)
				cc = cc + 1
				datasave("cc", cc)
				hit = true
			end
		end
	end
end

function boundcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	local xmax = getmapwidth(getentitymap(this))
	local ymax = getmapheight(getentitymap(this))
	
	if x < 0 or x > xmax or y < 0 or y > ymax then
		entitydestroy(this)
	end
end

function destroy()
	if hit == true then
		if destroytimer <= 0 then
			entitydestroy(this)
		else
			destroytimer = destroytimer - 1
		end
	end
end