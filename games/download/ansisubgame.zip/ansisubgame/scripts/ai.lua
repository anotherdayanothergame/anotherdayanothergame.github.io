function runonce()
	
end

function initialized()
	print("created")
	hull = 99
	entitydatasave(this, "seen", 0)
	setentitytile(this, 42, 1, 142)
	movetimer = 60
	depthtimer = 30
	shottimer = 30
end

function always()
	--[[if entityexists(player) then
		cc = dataread("cc")
		hullcheck()
		hitcheck()
		depthcheck()
		timercheck()
		move()
		depthcompare()
		shotcheck()
	end]]--
end

function main()
	if entityexists(player) then
		cc = dataread("cc")
		hullcheck()
		hitcheck()
		depthcheck()
		timercheck()
		move()
		depthcompare()
		shotcheck()
	end
end

--[[ function walkedon()
	local dmg = 33 + random(-5, 5)
	hull = hull - dmg
	print(hull)
end

function activated()
	local dmg = 33 + random(-5, 5)
	hull = hull - dmg
	print(hull)
end ]]--

function hullcheck()
	if hull <= 0 then
		print("Enemy destroyed")
		entitydestroy(this)
	end
end

function hitcheck()
	local x = getentityx(this)
	local y = getentityy(this)
	-- print("x = " .. tostring(x) .. " y = " .. tostring(y))
	local layer = getentitylayer(this)
	local ent = getmapentities(getentitymap(this))
	local i, ptr
	
	for i, ptr in ipairs(ent) do
		if getentityname(ptr) == "PlayerTorpedo" then
			local ex, ey = getentityxy(ptr)
			local elayer = getentitylayer(ptr)
			if ex == x and ey == y and elayer == layer then
				local dmg = 33 + random(-5, 5)
				hull = hull - dmg
				datasave(tostring(cc), "TARGET HIT")
				datasave(tostring(cc) .. "sym", 15)
				cc = cc + 1
				datasave("cc", cc)
				entitydestroy(ptr)
				print(hull)
			end
		end
	end
end

function depthcheck()
	local layer  = getentitylayer(this)
	local p_layer = getentitylayer(player)
	
	if layer > p_layer then
		setentitytilechar(this, 31)
	elseif layer < p_layer then
		setentitytilechar(this, 30)
	elseif layer == p_layer then
		setentitytilechar(this, 42)
	end
end

function timercheck()
	if movetimer > 0 then
		movetimer = movetimer - 1
	end
	if depthtimer > 0 then
		depthtimer = depthtimer - 1
	end
end

function move()
	local x = getentityx(this)
	local y = getentityy(this)
	local px = getentityx(player)
	local py = getentityy(player)
	local diffx = math.abs(px - x)
	local diffy = math.abs(py - y)
	
	if diffx < diffy and diffy < 10 then
		if x == px then
			if diffy > 4 then
				if py > y then
					if movetimer <= 0 then
						entityposition(this, x, y + 1)
						movetimer = 60
					end
				elseif py < y then
					if movetimer <= 0 then
						entityposition(this, x, y - 1)
						movetimer = 60
					end
				end
			end
		elseif x ~= px then
			if px > x then
				if movetimer <= 0 then
					entityposition(this, x + 1, y)
					movetimer = 60
				end
			elseif px < x then
				if movetimer <= 0 then
					entityposition(this, x - 1, y)
					movetimer = 60
				end
			end
		end
	elseif diffy < diffx and diffx < 10 then
		if y == py then
			if diffx > 4 then
				if px > x then
					if movetimer <= 0 then
						entityposition(this, x + 1, y)
						movetimer = 60
					end
				elseif px < x then
					if movetimer <= 0 then
						entityposition(this, x - 1, y)
						movetimer = 60
					end
				end
			end
		elseif y ~= py then
			if py > y then
				if movetimer <= 0 then
					entityposition(this, x, y + 1)
					movetimer = 60
				end
			elseif py < y then
				if movetimer <= 0 then
					entityposition(this, x, y - 1)
					movetimer = 60
				end
			end
		end
	elseif (diffx == diffy and x ~= px and y ~= py and diffx < 10 and diffy < 10) then
		local rand = math.random(1, 10)
		
		if (rand <= 5) then
			if px > x then
				if movetimer <= 0 then
					entityposition(this, x + 1, y)
					movetimer = 60
				end
			elseif px < x then
				if movetimer <= 0 then
					entityposition(this, x - 1, y)
					movetimer = 60
				end
			end
		elseif (rand > 5) then
			if py > y then
				if movetimer <= 0 then
					entityposition(this, x, y + 1)
					movetimer = 60
				end
			elseif py < y then
				if movetimer <= 0 then
					entityposition(this, x, y - 1)
					movetimer = 60
				end
			end
		end
	end
end

function depthcompare()
	local layer  = getentitylayer(this)
	local p_layer = getentitylayer(player)
	local x = getentityx(this)
	local y = getentityy(this)
	local px = getentityx(player)
	local py = getentityy(player)
	local diffx = math.abs(px - x)
	local diffy = math.abs(py - y)
	
	if (px == x or py == y) and diffx < 7 and diffy < 7 and layer > p_layer then
		if depthtimer <= 0 then
			setentitylayer(this, layer - 1)
			datasave(tostring(cc), "ENEMY ASCENDED")
			datasave(tostring(cc) .. "sym", 24)
			cc = cc + 1
			datasave("cc", cc)
			depthtimer = 30
		end
	elseif (px == x or py == y) and diffx < 7 and diffy < 7 and layer < p_layer then
		if depthtimer <= 0 then
			setentitylayer(this, layer + 1)
			datasave(tostring(cc), "ENEMY DOVE")
			datasave(tostring(cc) .. "sym", 25)
			cc = cc + 1
			datasave("cc", cc)
			depthtimer = 30
		end
	end
end

function shotcheck()
	local layer  = getentitylayer(this)
	local p_layer = getentitylayer(player)
	local x = getentityx(this)
	local y = getentityy(this)
	local px = getentityx(player)
	local py = getentityy(player)
	local diffx = math.abs(px - x)
	local diffy = math.abs(py - y)
	
	if shottimer > 0 then
		shottimer = shottimer - 1
	end
	
	if (layer == p_layer and x == px and diffy < 7 and shottimer == 0) then
		if py > y then
			torp = entitycreate("EnemyTorpedo", x, y, getentitymap(this))
			setentityscript(torp, "root:scripts/enemytorp.lua")
			initentityscript(torp)
			setentitytile(torp, 7, 1, 142)
			entitydatasave(torp, "dir", 2)
			entitydatasave(torp, "layer", layer)
			shottimer = 60
		elseif py < y then
			torp = entitycreate("EnemyTorpedo", x, y, getentitymap(this))
			setentityscript(torp, "root:scripts/enemytorp.lua")
			initentityscript(torp)
			setentitytile(torp, 7, 1, 142)
			entitydatasave(torp, "dir", 0)
			entitydatasave(torp, "layer", layer)
			shottimer = 60
		end
	elseif (layer == p_layer and y == py and diffx < 7 and shottimer == 0) then
		if px > x then
			torp = entitycreate("EnemyTorpedo", x, y, getentitymap(this))
			setentityscript(torp, "root:scripts/enemytorp.lua")
			initentityscript(torp)
			setentitytile(torp, 7, 1, 142)
			entitydatasave(torp, "dir", 1)
			entitydatasave(torp, "layer", layer)
			shottimer = 60
		elseif px < x then
			torp = entitycreate("EnemyTorpedo", x, y, getentitymap(this))
			setentityscript(torp, "root:scripts/enemytorp.lua")
			initentityscript(torp)
			setentitytile(torp, 7, 1, 142)
			entitydatasave(torp, "dir", 3)
			entitydatasave(torp, "layer", layer)
			shottimer = 60
		end
	end
end